"""Run from Codex, which services calls/ requests using fresh Astra subagents."""
from dataclasses import asdict
import argparse
import json
from pathlib import Path
import time

from .data import load_suc_data
from .llm import LLMConfig
from .master import QuantumConfig
from .solver import BendersConfig, solve_benders, result_to_dict
from .subagent import initialize, publish, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data/suc_10x24.json")
    parser.add_argument("--scenario-file")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--time-limit-seconds", type=float)
    parser.add_argument("--max-llm-calls", type=int)
    parser.add_argument("--original-feedback", action="store_true")
    args = parser.parse_args()
    if args.rounds < 1 or (args.time_limit_seconds is not None and args.time_limit_seconds <= 0):
        parser.error("rounds and time limit must be positive")
    data, scenarios = load_suc_data(args.data, args.scenario_file)
    root = Path(args.output_dir).resolve()
    llm = LLMConfig(enabled=True, api_format="codex_subagent", model="gpt-6-astra",
                    reasoning_effort="max", max_tokens=None, timeout_seconds=None,
                    max_retries=1, collect_diagnostics=True, exchange_dir=str(root),
                    enhanced_feedback=not args.original_feedback, max_calls=args.max_llm_calls)
    config = BendersConfig(max_iterations=args.rounds, master_encoding="dynamic",
        decomposition="none", decommit_candidates=False, random_candidates=False,
        stop_on_no_new_candidates=False, time_limit_seconds=args.time_limit_seconds,
        collect_diagnostics=True, quantum=QuantumConfig(kaiwu_seed=args.seed, candidate_pool_size=16), llm=llm)
    initialize(root, dict(arguments=vars(args), configuration=asdict(config),
        inputs={args.data: sha(args.data), **({args.scenario_file: sha(args.scenario_file)} if args.scenario_file else {})},
        sources={str(p): sha(p) for p in Path(__file__).parent.glob("*.py")}))
    started = time.perf_counter()
    publish(root / "state.json", dict(status="running"))
    with (root / "events.jsonl").open("a", encoding="utf-8", buffering=1) as stream:
        def event(row):
            serialized = result_to_dict(row)
            stream.write(json.dumps(serialized, ensure_ascii=False, allow_nan=False)+"\n")
            if row["kind"] == "evaluation" and row["improved"]:
                publish(root / "best-checkpoint.json", serialized)
            if row["kind"] == "iteration":
                print(f"ROUND {row['iteration']} objective={row['incumbent']}", flush=True)
        config.event_sink = event
        try:
            result = solve_benders(data, scenarios, config)
            publish(root / "result.json", result_to_dict(result))
            publish(root / "state.json", dict(status=result.status, elapsed_seconds=time.perf_counter()-started))
        except BaseException as exc:
            publish(root / "state.json", dict(status="interrupted" if isinstance(exc, KeyboardInterrupt) else "failed",
                    error_type=type(exc).__name__, elapsed_seconds=time.perf_counter()-started))
            raise


if __name__ == "__main__":
    main()
