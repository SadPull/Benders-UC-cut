"""Apply the user's inclusive 1% amendment through the existing cancel channel."""
import json
from pathlib import Path
import time

from suc_benders.subagent import publish

root = Path('results/rts24-deepseek-burst-20261002')
reference = json.loads((root/'reference.json').read_text(encoding='utf-8'))['objective']
target = reference * 1.01
with (root/'events.jsonl').open(encoding='utf-8') as stream:
    while True:
        position = stream.tell()
        line = stream.readline()
        if line and line.endswith('\n'):
            event = json.loads(line)
            if event['kind'] == 'evaluation' and event['feasible'] and event['objective'] <= target:
                # The evaluation event is emitted only after full physical/cost validation.
                trigger = dict(reason='amended_reference_target', requested_difference=.01,
                    comparison='<=', reference_cost=reference, target_cost=target,
                    objective=event['objective'], evaluation_count=event['evaluation_count'],
                    iteration=event['iteration'], event_elapsed_seconds=event['elapsed_seconds'],
                    observed_clock=time.perf_counter(), observed_at=time.time())
                publish(root/'cancel.json', trigger)
                publish(root/'stop-trigger.json', trigger)
                print(json.dumps(trigger), flush=True)
                break
        else:
            stream.seek(position)
            state = json.loads((root/'state.json').read_text(encoding='utf-8'))
            if state['status'] != 'running':
                print('Worker ended: '+state['status'], flush=True)
                break
            time.sleep(.001)
