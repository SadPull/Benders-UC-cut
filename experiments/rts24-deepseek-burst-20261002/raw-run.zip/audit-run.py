"""Offline audit of the user-stopped run, including incomplete calls."""
import json
from pathlib import Path
import zipfile

from suc_benders.attribution import validate_schedule
from suc_benders.data import load_suc_data
from suc_benders.rts24_experiment import schedule_object
from suc_benders.subagent import publish, sha

root = Path('results/rts24-deepseek-burst-20261002')
baseline = Path('experiments/rts24-sa-llm-burst-20261002')
read = lambda name: json.loads((root/name).read_text(encoding='utf-8-sig'))
events = [json.loads(s) for s in (root/'events.jsonl').read_text(encoding='utf-8').splitlines()]
best, reference, manifest, stop = [read(p) for p in ('best-schedule.json','reference.json','run.json','user-stop.json')]
assert not (root/'result.json').exists() and stop['status']=='USER_STOPPED'
assert all(sha(root/'source'/Path(p).name)==h for p,h in manifest['sources'].items())
assert all(sha(root/'inputs'/Path(p).name)==h for p,h in manifest['inputs'].items())
data, scenarios = load_suc_data(root/'inputs/units.json',root/'inputs/stochastic.json')
physical = [dict(evaluation=e['evaluation_count'], **validate_schedule(data,scenarios,schedule_object(e)))
            for e in events if e['kind']=='evaluation' and e['feasible']]
assert best['objective']==min(e['objective'] for e in events if e['kind']=='evaluation' and e['feasible'])
assert best['objective']>reference['objective']*1.01
publish(root/'physical-audit.json',dict(reference=validate_schedule(data,scenarios,schedule_object(reference)),
    best=validate_schedule(data,scenarios,schedule_object(best)),candidates=physical))

remaining = stalled = sa_calls = llm_calls = 0
incumbent = previous_feedback = None
calls, timeline = [], []
for index,event in enumerate(events):
    kind=event['kind']
    if kind=='evaluation':
        incumbent=event['incumbent']
    elif kind=='sa_start':
        assert remaining==0
        sa_calls+=1
    elif kind=='sa_round_validated':
        assert remaining==0 and event['iteration']==sa_calls
        improvement=(event['incumbent_before']-event['incumbent'])/abs(event['incumbent_before'])
        stalled=0 if improvement>=.0005 else stalled+1
        assert event['stalled']==stalled and event['llm_due']==(stalled>=3)
        timeline.append(dict(stage=f'SA {sa_calls}',cost=incumbent,stalled=stalled))
        if stalled>=3:
            remaining=3
    elif kind=='llm_start':
        assert remaining>0
        llm_calls+=1
        assert event['call_index']==llm_calls and event['batch_index']==4-remaining
        directory=f'calls/{llm_calls:03d}'
        if not (root/directory/'diagnostics.json').exists():
            assert llm_calls==stop['inflight_call'] and index==len(events)-1
            calls.append(dict(call=llm_calls,sa_round=sa_calls,completed=False,
                status='interrupted_waiting_for_response',usage=None,request_body_saved=False))
            continue
        d=read(f'{directory}/diagnostics.json')
        request,response=read(f'{directory}/request.json'),read(f'{directory}/response.json')
        assert request==d['request'] and response==d['response']
        assert request['model']==response['model']=='deepseek-flash'
        assert d['endpoint']=='https://api.deepseek.com/chat/completions'
        assert request['reasoning_effort']=='max' and 'temperature' not in request and 'max_tokens' not in request
        assert len(d['attempts'])==1 and d['attempts'][0]['status_code']==200
        for message in request['messages']:
            assert (root/directory/f"{message['role']}.txt").read_bytes()==message['content'].encode()
        user=read(f'{directory}/user.txt')
        prior=[e for e in events[:index] if e['kind']=='evaluation' and e['improved']][-1]
        assert user['incumbent_u']==prior['u'] and user['context']['previous_call_feedback']==previous_feedback
        feedback=read(f'{directory}/feedback.json')
        calls.append(dict(call=llm_calls,sa_round=sa_calls,completed=True,failed=d['failed'],message=d['message'],
            stop_reason=d.get('stop_reason'),elapsed_seconds=d['elapsed_seconds'],http_seconds=d['attempts'][0]['elapsed_seconds'],
            usage=response.get('usage'),raw_candidates=d['raw_count'],valid_candidates=d['valid_count'],
            validated=sum(p['validation_completed'] for p in feedback['proposals']),
            repaired_bits=[p['repair_bits'] for p in feedback['proposals']]))
    elif kind=='llm_feedback':
        previous_feedback=event['feedback']
        assert previous_feedback==read(f'calls/{llm_calls:03d}/feedback.json')
        remaining-=1
        timeline.append(dict(stage=f'LLM {llm_calls}',cost=incumbent,stalled=None))
        if remaining==0:
            stalled=0
assert llm_calls==11 and sa_calls==14 and remaining==2
publish(root/'protocol-audit.json',dict(passed=True,status='USER_STOPPED',target_reached=False,
    calls=calls,timeline=timeline,sa_calls=sa_calls,llm_calls_started=llm_calls,
    initial_stop=dict(difference=.005,comparison='<'),amended_stop=dict(difference=.01,comparison='<=')))

with zipfile.ZipFile(baseline/'raw-run.zip') as z:
    old_manifest=json.loads(z.read('run.json'))
    assert manifest['inputs']==old_manifest['inputs']
    cfg,old_cfg=dict(manifest['configuration']),dict(old_manifest['configuration'])
    cfg.pop('target_cost');old_cfg.pop('target_cost')
    llm,old_llm=cfg.pop('llm'),old_cfg.pop('llm')
    assert cfg==old_cfg
    for field in ('api_format','base_url','model','temperature','exchange_dir'):
        llm.pop(field);old_llm.pop(field)
    assert llm==old_llm
    unchanged=('paper_solver.py','paper_model.py','quantum.py','master.py','candidates.py','subproblem.py',
               'solver.py','full_model.py','context.py','advisor_feedback.py','data.py','common.py')
    assert all((root/'source'/n).read_bytes()==z.read('source/'+n) for n in unchanged)
    prompts={n:(root/'calls/001'/n).read_bytes()==z.read('calls/001/'+n) for n in ('system.txt','user.txt')}
    old_events=[json.loads(s) for s in z.read('events.jsonl').decode().splitlines()]
    def initial(rows):
        rows=rows[:next(i for i,e in enumerate(rows) if e['kind']=='llm_start')]
        return [(e['u'],e['objective']) for e in rows if e['kind']=='evaluation']
    a,b=initial(events),initial(old_events)
    assert len(a)==len(b) and all(x[0]==y[0] and abs(x[1]-y[1])<1e-4 for x,y in zip(a,b))
    assert all(prompts.values())
    prior_ref=json.loads(z.read('reference.json'))['objective']
    prior_hit=next(e for e in old_events if e['kind']=='evaluation' and e['feasible'] and e['objective']<=prior_ref*1.01)
    assert prior_hit['objective']==json.loads(z.read('result.json'))['objective']
publish(root/'comparison-parity.json',dict(passed=True,algorithm_sources_identical=list(unchanged),
    initial_sa_candidates_and_costs_identical=True,first_business_prompt_byte_parity=prompts,
    search_configuration_identical_except_provider=True,stopping_rule_amended_midrun=True))

completed=[c for c in calls if c['completed']]
usage={k:sum(c['usage'].get(k,0) for c in completed) for k in ('prompt_tokens','completion_tokens','total_tokens')}
cost,ref,lower=best['objective'],reference['objective'],reference['lower_bound']
summary=dict(status='USER_STOPPED',target_reached=False,requested_difference=.01,comparison='<=',
    model='deepseek-flash',objective=cost,reference_cost=ref,reference_difference=cost/ref-1,
    reference_lower_bound=lower,certified_gap_using_reference_lower=(cost-lower)/lower,
    sa_calls=sa_calls,llm_calls_started=llm_calls,llm_calls_completed=len(completed),
    failed_calls=[c['call'] for c in completed if c['failed']],inflight_interrupted_calls=[11],
    last_improvement_call=7,last_improvement_sa_round=best['iteration'],
    search_wall_seconds_estimate=stop['search_wall_seconds_estimate'],reference_runtime_seconds=reference['runtime'],
    completed_http_seconds=sum(c['http_seconds'] for c in completed),known_completed_usage=usage,
    total_run_usage=None,unknown_usage_calls=[11],preflight_usage=read('chat-preflight.json')['response']['usage'],
    complete_feasible_validations=len(physical),code_commit=read('environment.json')['code_commit'],audit_passed=True)
publish(root/'summary.json',summary)
old=json.loads((baseline/'summary.json').read_text(encoding='utf-8'))
publish(root/'paired-comparison.json',dict(astra=old,deepseek=summary,scope='single seed; stopped trial, provider contexts and transport differ'))
lines=['# RTS-24：DeepSeek Flash 与 Astra 对比（用户停止）','',
    '**本次按用户要求停止，未达到 1% 目标。** 最佳可行成本为 '+f'**{cost:.6f}**，参考差 **{100*(cost/ref-1):.6f}%**。','',
    '|指标|Astra / max|DeepSeek Flash / max|','|---|---:|---:|',
    f'|最佳可行成本|{old["objective"]:.6f}|{cost:.6f}|',
    f'|参考成本差|{100*old["reference_difference"]:.6f}%|{100*(cost/ref-1):.6f}%|',
    f'|SA 调用|{old["sa_calls"]}|{sa_calls}|',
    f'|LLM 调用|{old["llm_calls"]} 次完成|{llm_calls} 次启动；{len(completed)} 次完成；1 次中断|',
    f'|搜索总耗时|{old["solver_runtime_seconds"]:.2f} 秒|约 {stop["search_wall_seconds_estimate"]:.2f} 秒|',
    f'|独立参考求解|{old["reference_runtime_seconds"]:.2f} 秒|{reference["runtime"]:.2f} 秒|',
    '|≤1% 目标|达到|未达到|','',
    '两次均使用 32 机组 × 24 小时、三场景、种子 7、动态整时域 SA、候选池 16、每次最多 4 个候选。',
    '首次 LLM 业务提示词逐字节一致，首次调用前 SA 候选及成本一致；算法源码、修复与验证流程、搜索参数一致。参考值不进入业务提示词。',
    '连续三轮 SA 改善不足 0.05% 后连续调用 LLM 三次；每次先验证并更新最佳解及反馈，组末清零停滞计数。','',
    '初始停止条件为参考差严格小于 0.5%。用户在第 8 次请求期间改为 ≤1%，未重启实验，通过监督器监听完整验证事件并使用既有取消通道。',
    '随后用户要求直接停止；当时第 11 次 HTTP 请求仍在等待响应。求解进程和监督器均已终止。保留原始 running 状态及进程停止证据，没有伪造正常完成的 result.json。',
    'Astra 原运行达到 <0.5%；核对其历史轨迹，按 ≤1% 的首次达标也发生于同一个最终候选。本次 DeepSeek 未达到两个门槛，不能报告其达标耗时。','',
    '最后一次刷新最佳解来自第 7 次 LLM 调用（SA 第 11 轮）。第 8、9、10 次连续耗尽服务端约 128K 生成额度，返回 length，未生成可验证候选。',
    '这说明后期停滞包含明确的生成截断问题；不能据此认定算法已到数学上的局部最优。没有自动重试或更改 max 推理设置。',
    f'已完成调用的已知输入/输出/总 token 为 **{usage["prompt_tokens"]}/{usage["completion_tokens"]}/{usage["total_tokens"]}**；失败调用也计入。',
    '第 11 次仅保留开始事件及中断记录，其原始请求体未在响应前落盘，响应和最终 token 用量未知；不能把未知用量记为零。远端服务是否继续计费无法从本地确认。',
    'API 兼容性试请求单独归档，不计入正式优化调用；未将密钥写入配置、请求归档或日志。','',
    f'独立参考成本 {ref:.6f}、下界 {lower:.6f}；基于该下界的认证差距为 {100*(cost-lower)/lower:.6f}%。',
    '全部已完成可行候选和最终检查点均通过独立物理/成本审计；调度计数及逐次反馈一致性审计通过。',
    'DeepSeek 总耗时依据初始运行状态与停止记录的文件时间估算；Astra 为原生结果记录。两者均含等待、验证等开销，不能视作纯推理速度对比。',
    'Astra 还有 Codex 子代理环境与文件访问指令，DeepSeek 使用官方 HTTP 接口；两者完整模型上下文和服务默认生成参数并不相同。单种子、中途变更并主动停止的实验不能外推普遍优劣。','',
    '|阶段|已验证最佳成本|参考差|SA 停滞计数|','|---|---:|---:|---:|']
for row in timeline:
    lines.append(f"|{row['stage']}|{row['cost']:.6f}|{100*(row['cost']/ref-1):.6f}%|{row['stalled'] if row['stalled'] is not None else '—'}|")
lines+=['',f"运行源码提交 `{summary['code_commit']}`；运行前 32 项相关回归测试通过。完整档案含代码与输入快照、全部已完成请求/响应、反馈、检查点、停止与协议变更记录。"]
(root/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
