"""Offline audit/report for the completed RTS-24 burst experiment."""
import json
from pathlib import Path

from suc_benders.astra_audit import audit
from suc_benders.attribution import validate_schedule
from suc_benders.data import load_suc_data
from suc_benders.rts24_experiment import schedule_object
from suc_benders.subagent import publish, sha

root = Path('results/rts24-sa-llm-burst-20261002')
read = lambda name: json.loads((root/name).read_text(encoding='utf-8'))
events = [json.loads(line) for line in (root/'events.jsonl').read_text(encoding='utf-8').splitlines()]
result, reference, comparison = read('result.json'), read('reference.json'), read('comparison.json')
manifest = read('run.json')
assert all(sha(root/'source'/Path(path).name) == digest for path, digest in manifest['sources'].items())
assert all(sha(root/'inputs'/Path(path).name) == digest for path, digest in manifest['inputs'].items())
data, scenarios = load_suc_data(root/'inputs/units.json', root/'inputs/stochastic.json')
exchange_audit = audit(root)
physical = [dict(iteration=e['iteration'], evaluation_count=e['evaluation_count'],
    **validate_schedule(data, scenarios, schedule_object(e)))
    for e in events if e['kind'] == 'evaluation' and e['feasible']]
publish(root/'physical-audit.json', dict(reference=validate_schedule(data, scenarios, schedule_object(reference)),
    best=validate_schedule(data, scenarios, schedule_object(result)), candidates=physical))

stalled, remaining, call_index, sa_round, incumbent = 0, 0, 0, 0, None
timeline, target_indices = [], []
for index, event in enumerate(events):
    kind = event['kind']
    if kind == 'sa_start':
        assert remaining == 0
        sa_round += 1
    elif kind == 'evaluation':
        incumbent = event['incumbent']
        if event['feasible'] and event['objective'] < reference['objective'] * 1.005:
            target_indices.append(index)
    elif kind == 'sa_round_validated':
        assert remaining == 0 and event['iteration'] == sa_round
        improvement = (event['incumbent_before']-event['incumbent']) / abs(event['incumbent_before'])
        stalled = 0 if improvement >= .0005 else stalled+1
        assert event['stalled'] == stalled and event['llm_due'] == (stalled >= 3)
        timeline.append(dict(stage=f'SA {sa_round}', cost=incumbent, stalled=stalled))
        if stalled >= 3:
            remaining = 3
    elif kind == 'llm_start':
        assert remaining > 0
        call_index += 1
        assert event['call_index'] == call_index and event['batch_index'] == 4-remaining
        user = read(f'calls/{call_index:03d}/user.txt')
        prior = [e for e in events[:index] if e['kind'] == 'evaluation' and e['improved']][-1]
        assert user['incumbent_u'] == prior['u']
    elif kind == 'llm_feedback':
        remaining -= 1
        timeline.append(dict(stage=f'LLM {call_index}', cost=incumbent, stalled=None))
        if remaining == 0:
            stalled = 0

assert len(target_indices) == 1 and result['status'] == 'TARGET_REACHED'
trigger = events[target_indices[0]]
assert not any(e['kind'] in {'sa_start', 'llm_start', 'dispatch_start', 'evaluation'}
               for e in events[target_indices[0]+1:])
assert comparison['target_reached'] and comparison['reference_difference'] < .005
assert trigger['objective'] == result['objective']
publish(root/'protocol-audit.json', dict(passed=True, sa_calls=sa_round, llm_calls=call_index,
    target_event=trigger, no_search_after_target=True, timeline=timeline))

ref, cost, lower = reference['objective'], result['objective'], reference['lower_bound']
summary = dict(status=result['status'], objective=cost, reference_cost=ref,
    reference_difference=cost/ref-1, reference_lower_bound=lower,
    certified_gap_using_reference_lower=(cost-lower)/lower, sa_calls=sa_round,
    llm_calls=call_index, solver_runtime_seconds=result['runtime'],
    reference_runtime_seconds=reference['runtime'], trigger_source=trigger['source'],
    trigger_evaluation=trigger['evaluation_count'], complete_feasible_validations=len(physical),
    code_commit=read('environment.json')['code_commit'], audit_passed=True)
publish(root/'summary.json', summary)
lines = ['# RTS-24 三场景 SUC：SA 停滞后三次 LLM 调用实验', '',
    f"状态：**{result['status']}**。每个完整验证候选均重新通过物理与成本检查；交换及调度审计通过。", '',
    f'- 最佳可行成本：**{cost:.6f}**。',
    f'- 独立 Gurobi 参考成本：{ref:.6f}；相对参考差：**{100*(cost/ref-1):.6f}%**，严格低于 0.5%。',
    f'- 参考下界：{lower:.6f}；基于该下界的认证差距：{100*(cost-lower)/lower:.6f}%。',
    f'- SA 调用 {sa_round} 次；独立 Astra 调用 {call_index} 次；完整可行验证 {len(physical)} 次。',
    f'- 搜索耗时（含调度和模型等待）：{result["runtime"]:.2f} 秒；参考求解 {reference["runtime"]:.2f} 秒。',
    f'- 触发停止的候选：{trigger["source"]}，完整验证序号 {trigger["evaluation_count"]}；之后没有继续搜索或调用。', '',
    '使用 IEEE RTS-24 派生的 32 机组 × 24 小时无网络模型，三场景倍率 0.90/1.00/1.05、概率 0.25/0.50/0.25、备用 5%。',
    'SA 种子 7、候选池 16、动态整时域编码；关闭独立减开机和随机候选。',
    '连续三轮 SA 降本不足轮前成本 0.05% 后，顺序调用 gpt-6-astra/max 三次；每次候选验证后更新最佳解、生成反馈及下一次输入。组末清零停滞计数。',
    '参考值仅用于停止判断和报告，不提供给子代理。参考差不等同于 SA 自身证明的最优性差距。单种子实验不证明速度或一般精度优势。', '',
    '|阶段|已验证最佳成本|参考差|SA 停滞计数|', '|---|---:|---:|---:|']
for row in timeline:
    lines.append(f"|{row['stage']}|{row['cost']:.6f}|{100*(row['cost']/ref-1):.6f}%|{row['stalled'] if row['stalled'] is not None else '—'}|")
lines += ['', f"运行源码提交：`{summary['code_commit']}`。全量回归：173 项通过。", '',
    '完整配置、输入、源码快照、调用文件、完整调度、事件和检查点均保存在归档中。']
(root/'report.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
