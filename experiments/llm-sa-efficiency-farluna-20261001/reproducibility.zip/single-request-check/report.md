# Farluna 单次截断检测（2026-10-01）

本次未截断。用旧实验首次发生截断的完整调度 prompt 重放一次，仅更换接口和模型名。

- 请求：https://api.farluna.tech/v1/chat/completions；模型 farluna/deepseek-v4.1-flash。
- 参数：reasoning_effort=max、max_tokens=65536、temperature=0.2、stream=false。
- HTTP 200，finish_reason=stop；返回模型名 deepseek-v4.1-flash。
- 耗时268.73秒；本次检测单次等待上限300秒，没有重试。
- 推理35380 tokens，正文2097 tokens，completion总计37478 tokens（按服务用量记录原样保留，各子项存在1 token差异）。
- JSON解析成功，正文2608字符，包含4个格式正确的10×24二元候选矩阵。
- 共1次API请求，0次SA、0次调度求解；没有评估候选物理可行性或成本。

相比旧接口的32000个推理token、零正文、length结束，本次确实越过该长度并正常输出。
这证明该代表性请求可以完成，不保证所有后续请求均不截断。
正式效率实验的单次LLM超时仍为180秒，本次响应超过该上限；本次没有修改正式实验预算或启动重跑。

请求、完整响应、摘要及源轨迹指纹保存在同目录。密钥只保存在Git忽略的.env中。
相关15项本地测试通过，详见tests.log。
