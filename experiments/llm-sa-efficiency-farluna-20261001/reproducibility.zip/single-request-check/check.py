import hashlib
import json
import time
from pathlib import Path
from urllib.request import Request, ProxyHandler, build_opener
from urllib.error import HTTPError

directory = Path(__file__).resolve().parent
source = Path('results/llm-sa-efficiency-20261001/runs/sa_llm__s17/events.jsonl')
record = next(json.loads(line) for line in source.read_text(encoding='utf-8').splitlines()
              if json.loads(line)['kind'] == 'llm_end')
payload = record['diagnostics']['request'].copy()
payload['model'] = 'farluna/deepseek-v4.1-flash'
token = next(line.split('=', 1)[1] for line in Path('.env').read_text(encoding='utf-8').splitlines()
             if line.startswith('LLM_API_KEY='))
endpoint = 'https://api.farluna.tech/v1/chat/completions'

def save(name, value):
    text = json.dumps(value, ensure_ascii=False, indent=2).replace(token, '[REDACTED]')
    (directory/name).write_text(text+'\n', encoding='utf-8')

assert not (directory/'request.json').exists(), 'Do not repeat or overwrite this single request'
save('request.json', payload)
save('provenance.json', {'endpoint': endpoint, 'source': source.as_posix(),
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'timeout_seconds': 300,
    'calls': 1, 'retries': 0, 'sa_calls': 0, 'dispatch_calls': 0,
    'same_messages_as_prior_truncated_request': True})
started = time.perf_counter()
summary = {'status': 'started', 'truncated': None, 'json_valid': False}
save('summary.json', summary)
try:
    request = Request(endpoint, data=json.dumps(payload).encode(),
        headers={'Authorization': 'Bearer '+token, 'Content-Type': 'application/json'})
    with build_opener(ProxyHandler({})).open(request, timeout=300) as response:
        summary['http_status'] = response.status
        raw = json.load(response)
    save('response.json', raw)
    choice = raw['choices'][0]
    content = choice['message'].get('content') or ''
    summary.update(status='response_received', finish_reason=choice.get('finish_reason'),
        truncated=choice.get('finish_reason') in ('length', 'max_tokens'),
        content_characters=len(content), returned_model=raw.get('model'), usage=raw.get('usage'))
    try:
        parsed = json.loads(content.strip().removeprefix('```json').removesuffix('```').strip())
        entries = parsed.get('candidates') if isinstance(parsed, dict) else parsed
        summary['json_valid'] = True
        summary['candidate_count'] = len(entries) if isinstance(entries, list) else None
        summary['binary_10x24_count'] = sum(
            isinstance(c, dict) and isinstance(c.get('u'), list) and len(c['u']) == 10
            and all(isinstance(row, list) and len(row) == 24 and all(v in (0, 1) for v in row) for row in c['u'])
            for c in entries) if isinstance(entries, list) else 0
    except (ValueError, TypeError):
        pass
except HTTPError as exc:
    summary.update(status='http_error', http_status=exc.code,
                   error=exc.read(4096).decode(errors='replace'))
except (OSError, ValueError, KeyError, IndexError, TypeError) as exc:
    summary.update(status='request_failed', error_type=type(exc).__name__)
summary['elapsed_seconds'] = time.perf_counter()-started
save('summary.json', summary)
print(json.dumps(summary, ensure_ascii=False).replace(token, '[REDACTED]'), flush=True)
