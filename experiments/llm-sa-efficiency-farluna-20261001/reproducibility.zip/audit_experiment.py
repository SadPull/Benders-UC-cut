"""Read-only validation of completed traces; writes only this study's audit.json."""
import json
import hashlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np

from suc_benders.attribution import validate_schedule, write_json
from suc_benders.data import load_suc_data
from suc_benders.efficiency_experiment import read_events, load_credentials
import os

directory=Path(__file__).resolve().parent
data,scenarios=load_suc_data('data/suc_10x24.json')
validated=0
maximum=0.
runs=[]
for path in sorted((directory/'runs').glob('*')):
    state=json.loads((path/'state.json').read_text(encoding='utf-8'))
    events=read_events(path/'events.jsonl')
    sa=0
    signatures=set()
    previous=float('inf')
    for e in events:
        if e['kind']=='sa_start':
            sa+=1
        assert e['sa_calls']==sa,(path.name,e['kind'],'SA sequence')
        if e['kind']!='evaluation':
            continue
        assert e['elapsed_seconds']<=state['budget'],(path.name,'late evaluation')
        assert e['commitment_id'] not in signatures,(path.name,'duplicate evaluation')
        signatures.add(e['commitment_id'])
        assert e['incumbent']<=previous+1e-6
        previous=e['incumbent']
        if not e['feasible']:
            continue
        result=SimpleNamespace(objective=e['objective'],**{k:np.array(e[k]) for k in ('u','v','w')},
            scenarios=[SimpleNamespace(**{**s,'p':np.array(s['p']),'r':np.array(s['r'])}) for s in e['scenarios']])
        check=validate_schedule(data,scenarios,result)
        maximum=max(maximum,check['max_residual_mw'])
        validated+=1
    runs.append({'run':path.name,'status':state['status'],'sa_calls':sa,'evaluations':len(signatures),
                 'events_sha256':hashlib.sha256((path/'events.jsonl').read_bytes()).hexdigest()})
load_credentials()
secret=os.environ['LLM_API_KEY'].encode()
assert all(secret not in p.read_bytes() for p in directory.rglob('*') if p.is_file()),'secret in artifact'
write_json(directory/'audit.json',{'validated_candidates':validated,'maximum_physical_residual_mw':maximum,
    'sa_counter_and_cutoff_checks':True,'no_duplicate_evaluation':True,'secret_scan_passed':True,'runs':runs})
print(json.dumps({'validated_candidates':validated,'maximum_physical_residual_mw':maximum,'runs':len(runs)}))
