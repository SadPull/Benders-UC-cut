"""One real Responses request against a frozen optimization context."""
import os
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

from dataclasses import asdict, replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import numpy as np
from suc_benders.attribution import validate_schedule
from suc_benders.candidates import commitment_hash, make_candidate
from suc_benders.data import load_suc_data
from suc_benders.efficiency_experiment import configuration, load_credentials, read_events
from suc_benders.llm import ask_llm_for_candidates
from suc_benders.solver import _fixed_cost, result_to_dict
from suc_benders.subproblem import solve_scenario

directory = Path(__file__).resolve().parent
source = ROOT / "results/llm-sa-efficiency-50rounds-20261001-180425/runs/sa_llm__s17/events.jsonl"
load_credentials()
secret = os.environ["LLM_API_KEY"]


def save(name, value):
    text = json.dumps(result_to_dict(value), ensure_ascii=False, indent=2, allow_nan=False)
    (directory / name).write_text(text.replace(secret, "[REDACTED]") + "\n", encoding="utf-8")


def main():
    events = read_events(source)
    old = next(e["diagnostics"] for e in events
               if e["kind"] == "llm_end" and e["diagnostics"]["iteration"] == 15)
    start_index = next(i for i, e in enumerate(events)
                       if e["kind"] == "llm_start" and e["iteration"] == 15)
    prior = events[:start_index]
    baseline = min((e for e in prior if e["kind"] == "evaluation" and e["feasible"]),
                   key=lambda e: e["objective"])
    cache = {e["commitment_id"]: e for e in prior if e["kind"] == "evaluation"}
    system, user = [m["content"] for m in old["request"]["messages"]]
    body = json.loads(user)
    assert np.array_equal(body["incumbent_u"], baseline["u"])
    data, scenarios = load_suc_data(ROOT / "data/suc_10x24.json")
    incumbent = make_candidate(data, scenarios, np.array(body["incumbent_u"]), source="incumbent")
    base = [make_candidate(data, scenarios, np.array(u)) for u in body["base_u"]]
    config = replace(configuration(17, "sa_llm", rounds=50).llm, api_format="responses")
    assert config.max_retries == 1 and config.timeout_seconds is None
    with (directory / "started.json").open("x", encoding="utf-8") as stream:
        json.dump({"pid": os.getpid(), "started_at": datetime.now(timezone.utc).isoformat(),
                   "maximum_http_requests": 1, "retries": 0}, stream)
    save("provenance.json", {
        "source": str(source.relative_to(ROOT)),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "source_iteration": 15, "configuration": asdict(config),
        "baseline_objective": baseline["objective"], "same_system_and_user_text": True,
        "original_chat_seconds": old["elapsed_seconds"], "original_chat_stop": old["stop_reason"],
        "sources": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted((ROOT / "suc_benders").glob("*.py"))},
    })
    save("request.json", {
        "model": config.model, "max_output_tokens": config.max_tokens,
        "temperature": config.temperature, "stream": False, "store": False,
        "reasoning": {"effort": config.reasoning_effort},
        "input": [{"role": "system", "content": system}, {"role": "user", "content": user}],
    })
    save("summary.json", {"status": "request_started", "http_request_limit": 1,
                          "baseline_objective": baseline["objective"]})
    print("Sending the only Responses request; no retries or client timeout.", flush=True)
    started = time.perf_counter()
    # Freeze the old prompt while exercising the production HTTP client and parser.
    with patch("suc_benders.llm._prompt", return_value=(system, user)):
        advice = ask_llm_for_candidates(data, scenarios, 15, [], incumbent, config,
                                        context=body["context"])
    save("diagnostics.json", advice.diagnostics)
    assert len(advice.diagnostics["attempts"]) == 1
    assert advice.diagnostics["request"] == json.loads((directory / "request.json").read_text())
    if "response" in advice.diagnostics:
        save("response.json", advice.diagnostics["response"])
    print(json.dumps({"message": advice.message, "seconds": advice.diagnostics["elapsed_seconds"],
                      "accepted_candidates": advice.valid_count}), flush=True)
    evaluations = []
    dispatch_calls = 0
    best = baseline["objective"]
    for candidate in advice.candidates:
        key = commitment_hash(candidate)
        if key in cache:
            cached = cache[key]
            evaluations.append({"commitment_id": key, "cached": True,
                                "feasible": cached["feasible"], "objective": cached["objective"]})
            continue
        results = []
        for scenario in scenarios:
            results.append(solve_scenario(data, scenario, candidate.u, candidate.v, candidate.w,
                                          output_flag=0, threads=1))
            dispatch_calls += 1
        feasible = all(x.feasible for x in results)
        row = {"commitment_id": key, "cached": False, "feasible": feasible,
               "objective": None, "u": candidate.u, "v": candidate.v, "w": candidate.w,
               "scenario_statuses": [x.status for x in results]}
        if feasible:
            cost = _fixed_cost(data, candidate.u, candidate.v, candidate.w) + sum(
                s.probability * x.objective for s, x in zip(scenarios, results))
            result = SimpleNamespace(objective=cost, u=candidate.u, v=candidate.v,
                                     w=candidate.w, scenarios=results)
            row.update(objective=cost, validation=validate_schedule(data, scenarios, result),
                       scenarios=[{"objective": x.objective, "p": x.p, "r": x.r} for x in results])
            best = min(best, cost)
        evaluations.append(row)
        print(json.dumps({"candidate": len(evaluations), "feasible": feasible,
                          "objective": row["objective"]}), flush=True)
    save("evaluations.json", evaluations)
    summary = {
        "status": "request_failed" if advice.failed else "completed",
        "message": advice.message, "http_requests": len(advice.diagnostics["attempts"]),
        "sa_calls": 0, "dispatch_calls": dispatch_calls,
        "llm_seconds": advice.diagnostics["elapsed_seconds"],
        "total_seconds": time.perf_counter() - started,
        "raw_candidates": advice.raw_count, "accepted_candidates": advice.valid_count,
        "new_feasible_candidates": sum(x["feasible"] and not x["cached"] for x in evaluations),
        "cached_candidates": sum(x["cached"] for x in evaluations),
        "baseline_objective": baseline["objective"], "best_objective": best,
        "improvement": baseline["objective"] - best,
        "response_status": advice.diagnostics.get("response_status"),
        "stop_reason": advice.diagnostics.get("stop_reason"), "usage": advice.diagnostics.get("usage"),
        "original_chat_seconds": old["elapsed_seconds"],
        "source_events_unchanged": hashlib.sha256(source.read_bytes()).hexdigest()
            == json.loads((directory / "provenance.json").read_text())["source_sha256"],
    }
    save("summary.json", summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        save("error.json", {"type": type(exc).__name__})
        raise
