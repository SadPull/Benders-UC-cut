"""Audit saved schedules and subagent receipts without any optimization calls."""
from pathlib import Path
from types import SimpleNamespace
import hashlib, json, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from suc_benders.attribution import validate_schedule, write_json
from suc_benders.data import load_suc_data
from suc_benders.efficiency_experiment import read_events
D=Path(__file__).resolve().parent
final='--final' in sys.argv
manifest=json.loads((D/'manifest.json').read_text())
protocol=json.loads((D/'protocol.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(ROOT/name)==value for name,value in manifest['sources'].items())
old=ROOT/'results/llm-sa-efficiency-50rounds-20261001-180425'
assert all(sha(old/name)==value for name,value in protocol['old_events_sha256'].items())
assert sha(D/'runs/sa__s7/events.jsonl')==protocol['reused_events_sha256']
data,scenarios=load_suc_data(ROOT/'data/suc_10x24.json')
validated=0; maximum=0.; cost_residual=0.; rows=[]; calls=0
for p in sorted((D/'runs').glob('*')):
 state=json.loads((p/'state.json').read_text())
 e=read_events(p/'events.jsonl')
 sa=0; previous=float('inf'); signatures=set()
 for x in e:
  if x['kind']=='sa_start':sa+=1
  assert x['sa_calls']==sa
  if x['kind']=='evaluation':
   assert x['commitment_id'] not in signatures
   signatures.add(x['commitment_id'])
   assert x['incumbent']<=previous+1e-6
   previous=x['incumbent']
   if x['feasible']:
    result=SimpleNamespace(objective=x['objective'],**{k:np.array(x[k]) for k in ('u','v','w')},scenarios=[SimpleNamespace(**{**s,'p':np.array(s['p']),'r':np.array(s['r'])}) for s in x['scenarios']])
    check=validate_schedule(data,scenarios,result)
    maximum=max(maximum,check['max_residual_mw']);cost_residual=max(cost_residual,check['cost_residual']);validated+=1
  if x['kind']=='llm_end':
   d=x['diagnostics'];assert d['transport']=='codex_subagent' and d['http_requests']==0
   assert d['synthetic_envelope'] and len(d['attempts'])==1
   c=p/'calls'/f"{d['iteration']:03d}"
   req=json.loads((c/'request.json').read_text()); rec=json.loads((c/'receipt.json').read_text())
   assert rec['model']=='gpt-6-astra' and rec['reasoning_effort']=='max' and rec['subagent_calls']==1
   assert rec['input_sha256']==req['input_sha256']
   assert all(sha(c/name)==value for name,value in rec['input_sha256'].items())
   assert sha(c/'candidates.json')==rec['output_sha256']
   assert rec==d['subagent_receipt'];calls+=1
 rounds=[x['iteration'] for x in e if x['kind']=='iteration']
 assert rounds==list(range(1,len(rounds)+1))
 if state['status']=='completed':
  assert len(rounds)==50 and sa==50
  assert sum(x['kind']=='llm_end' for x in e)==(50 if state['strategy']=='sa_llm' else 0)
 if final:assert state['status']=='completed'
 rows.append({'run':p.name,'status':state['status'],'completed_rounds':len(rounds),'sa_calls':sa,'events_sha256':sha(p/'events.jsonl')})
if final:assert len(rows)==10 and calls==250
secrets=[]
for line in (ROOT/'.env').read_text().splitlines():
 if line.startswith('LLM_API_KEY='):secrets.append(line.split('=',1)[1].strip().encode())
assert all(not secret or secret not in p.read_bytes() for p in D.rglob('*') if p.is_file() for secret in secrets)
result={'final':final,'validated_candidates':validated,'maximum_physical_residual_mw':maximum,'maximum_cost_residual':cost_residual,'verified_subagent_calls':calls,'old_trajectories_unchanged':True,'source_snapshot_matches':True,'secret_scan_passed':True,'runs':rows}
write_json(D/('audit.json' if final else 'audit-progress.json'),result)
print(json.dumps({k:v for k,v in result.items() if k!='runs'}))
