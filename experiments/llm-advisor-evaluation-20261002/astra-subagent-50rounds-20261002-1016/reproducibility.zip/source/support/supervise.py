from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from suc_benders.attribution import write_json
from suc_benders.efficiency_experiment import read_events, summarize
D=Path(__file__).resolve().parent
cmd=sys.argv[1]
if cmd in ('dispatch','accept'):
    call=D/'runs'/sys.argv[2]/'calls'/f'{int(sys.argv[3]):03d}'
    request=json.loads((call/'request.json').read_text(encoding='utf-8'))
    if cmd=='dispatch':
        with (call/'dispatch.json').open('x',encoding='utf-8') as f:
            json.dump({'agent_id':sys.argv[4],'model':'gpt-6-astra','reasoning_effort':'max','dispatched_at':datetime.now(timezone.utc).isoformat()},f)
    else:
        assert not (call/'receipt.json').exists()
        dispatch=json.loads((call/'dispatch.json').read_text())
        for name,value in request['input_sha256'].items():
            assert hashlib.sha256((call/name).read_bytes()).hexdigest()==value
        answer=(call/'candidates.json').read_bytes()
        parsed=json.loads(answer)
        assert isinstance(parsed,dict) and isinstance(parsed.get('candidates'),list)
        write_json(call/'receipt.json',{**dispatch,'input_sha256':request['input_sha256'],'output_sha256':hashlib.sha256(answer).hexdigest(),'subagent_calls':1,'accepted_at':datetime.now(timezone.utc).isoformat()})
    print(json.dumps({'action':cmd,'call':str(call)}))
else:
    ref=json.loads((D/'reference.json').read_text())['objective']
    rows=[]
    pending=[]
    for seed in (7,17,27,37,47):
        for strategy in ('sa','sa_llm'):
            p=D/'runs'/f'{strategy}__s{seed}'
            if not p.exists():
                rows.append({'run':p.name,'status':'not_started','rounds':0});continue
            state=json.loads((p/'state.json').read_text())
            e=read_events(p/'events.jsonl')
            s=summarize(e,None,ref)
            rows.append({'run':p.name,'status':state['status'],'rounds':s['completed_rounds'],'best':s['objective'],'reference_difference':s['relative_difference'],'SA':s['sa_calls'],'LLM':s['llm_calls'],'LLM_done':s['llm_completed'],'last_seconds':s['elapsed_seconds']})
            for c in sorted((p/'calls').glob('*')):
                if not (c/'receipt.json').exists():
                    pending.append({'run':p.name,'round':int(c.name),'path':str(c),'dispatched':(c/'dispatch.json').exists(),'answer_exists':(c/'candidates.json').exists()})
    stamp=datetime.now(timezone.utc).isoformat()
    lines=['# Astra 实验实时状态','',f'更新时间（UTC）：{stamp}。当前聊天人工逐轮监督，自动化保持暂停。','', '模型 gpt-6-astra，max；按用户最新要求，当前种子 7 最多 10 轮，相对参考成本差小于 0.1% 时提前停，不再启动其他种子。所有成本均来自已完成物理验证的调度。','', '|运行|状态|完成轮数|最佳成本|相对参考成本差|','|---|---|---:|---:|---:|']
    for r in rows:
        cost=f"{r['best']:.4f}" if r.get('best') is not None else '—'
        gap=f"{r['reference_difference']:.4%}" if r.get('reference_difference') is not None else '—'
        lines.append(f"|{r['run']}|{r['status']}|{r['rounds']}/{'10' if r['run']=='sa_llm__s7' else '50'}|{cost}|{gap}|")
    lines+=['','相对参考成本差不是认证 gap；量子真机调用为零。种子 7 SA 复用旧实验；其他种子的本次计划已取消。']
    (D/'live-status.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'rows':rows,'pending':pending},ensure_ascii=False))
