"""Release one existing answer and observe it in the current chat, up to 50 s.
No agent launches, scheduled monitoring, solver calls or automatic restarts.
"""
from datetime import datetime, timezone
from pathlib import Path
import json, re, subprocess, sys, time
import psutil
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from suc_benders.attribution import write_json
from suc_benders.efficiency_experiment import read_events
D=Path(__file__).resolve().parent
P=D/'runs/sa_llm__s7'
ref=json.loads((D/'reference.json').read_text(encoding='utf-8'))['objective']
meta=json.loads((D/'process.json').read_text(encoding='utf-8-sig'))
proc=psutil.Process(meta['pid'])
assert abs(proc.create_time()-datetime.fromisoformat(re.sub(r'(\.\d{6})\d+', r'', meta['started_at'])).timestamp())<1
assert proc.cmdline()[1:]==['-u','-m','suc_benders.subagent_experiment','--output-dir','results/astra-subagent-50rounds-20261002-1016']

def condition(events):
    best=min((e for e in events if e['kind']=='evaluation' and e['feasible']),key=lambda e:e['objective'],default=None)
    rounds=sum(e['kind']=='iteration' for e in events)
    reason='reference_difference_below_0.1_percent' if best and best['objective']/ref-1<.001 else 'ten_round_limit' if rounds>=10 else None
    return reason,best,rounds

if len(sys.argv)>1:
    subprocess.run([sys.executable,str(D/'supervise.py'),'accept','sa_llm__s7',sys.argv[1]],check=True)
started=time.monotonic()
while True:
    events=read_events(P/'events.jsonl')
    reason,best,rounds=condition(events)
    if reason:
        record={'reason':reason,'requested_max_rounds':10,'reference_difference_threshold':.001,
                'reference':ref,'best_objective':best['objective'],'relative_difference':best['objective']/ref-1,
                'completed_rounds_at_trigger':rounds,'best_iteration':best['iteration'],
                'triggered_at':datetime.now(timezone.utc).isoformat(),'worker_pid':proc.pid,'worker_create_time':proc.create_time()}
        write_json(D/'stop-trigger.json',record)
        proc.kill()
        proc.wait(timeout=5)
        events=read_events(P/'events.jsonl')
        state=json.loads((P/'state.json').read_text(encoding='utf-8'))
        state.update(status='user_stopped_threshold' if reason.startswith('reference') else 'user_stopped_round_limit',
                     stop_reason=reason,ended_at=datetime.now(timezone.utc).isoformat(),
                     amended_round_limit=10,completed_rounds=sum(e['kind']=='iteration' for e in events),
                     actual_sa_calls=sum(e['kind']=='sa_start' for e in events),actual_llm_calls=sum(e['kind']=='llm_start' for e in events))
        write_json(P/'state.json',state)
        record.update(worker_verified_stopped=True,final_state=state)
        write_json(D/'stop-trigger.json',record)
        print(json.dumps(record));break
    pending=[c for c in sorted((P/'calls').glob('*')) if (c/'request.json').exists() and not (c/'receipt.json').exists()]
    if pending:
        print(json.dumps({'status':'awaiting_chat_dispatch','round':int(pending[0].name),'completed_rounds':rounds,'best':best['objective']}));break
    if time.monotonic()-started>=50:
        print(json.dumps({'status':'still_validating','completed_rounds':rounds,'best':best['objective']}));break
    if not proc.is_running():raise RuntimeError('Worker exited before a stopping condition')
    time.sleep(.02)
