"""Finalize the user-shortened experiment from recorded evidence only."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,sys
import psutil
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from suc_benders.attribution import write_json
from suc_benders.efficiency_experiment import read_events,summarize
D=Path(__file__).resolve().parent
stop=json.loads((D/'stop-trigger.json').read_text(encoding='utf-8'))
try:
 p=psutil.Process(stop['worker_pid'])
 assert abs(p.create_time()-stop['worker_create_time'])>1,'Original experiment worker is still alive'
except psutil.NoSuchProcess:pass
subprocess.run([sys.executable,str(D/'audit.py')],check=True)
audit=json.loads((D/'audit-progress.json').read_text(encoding='utf-8'))
events=read_events(D/'runs/sa_llm__s7/events.jsonl')
ref=stop['reference']
best=min((e for e in events if e['kind']=='evaluation' and e['feasible']),key=lambda e:e['objective'])
complete=[e['iteration'] for e in events if e['kind']=='iteration']
started=[e['iteration'] for e in events if e['kind']=='llm_start']
returned=[e['diagnostics']['iteration'] for e in events if e['kind']=='llm_end']
assert len(complete)<=10 and started==returned and len(started)<=10
assert stop['reason']=='ten_round_limit' and len(complete)==10 or stop['reason']=='reference_difference_below_0.1_percent' and best['objective']/ref-1<.001
assert [p.name for p in (D/'runs').iterdir() if p.is_dir()]==['sa__s7','sa_llm__s7'] or set(p.name for p in (D/'runs').iterdir() if p.is_dir())=={'sa__s7','sa_llm__s7'}
rounds=[]
for iteration in started:
 d=next(e['diagnostics'] for e in events if e['kind']=='llm_end' and e['diagnostics']['iteration']==iteration)
 feasible=[e for e in events if e['kind']=='evaluation' and e['feasible'] and e['iteration']<=iteration]
 local=[e for e in feasible if e['iteration']==iteration and e['source']=='llm']
 rounds.append({'iteration':iteration,'complete':iteration in complete,'best_cost':min(e['objective'] for e in feasible),
  'raw_candidates':d['raw_count'],'accepted_candidates':d['valid_count'],'evaluated_feasible_llm_candidates':len(local),
  'repair_bits':[x.get('hamming_u') for x in d['proposals']], 'failed':d['failed'],'observed_request_seconds':d['elapsed_seconds']})
summary={'status':'completed_under_amended_user_stop_rule','original_50_round_protocol_completed':False,
 'active_seed':7,'completed_rounds':len(complete),'actual_subagent_calls':len(returned),
 'sa_calls_started':sum(e['kind']=='sa_start' for e in events),'sa_calls_completed':sum(e['kind']=='sa_end' and e['status']=='completed' for e in events),
 'best_objective':best['objective'],'reference_objective':ref,'relative_reference_difference':best['objective']/ref-1,
 'best_found_iteration':best['iteration'],'stop_reason':stop['reason'],'all_workers_stopped':True,
 'rounds':rounds,'observed_elapsed_seconds':max(e['elapsed_seconds'] for e in events),
 'reused_baseline':summarize(read_events(D/'runs/sa__s7/events.jsonl'),None,ref)}
write_json(D/'final-summary.json',summary)
write_json(D/'best-schedule.json',best)
audit.update(final_under_amended_protocol=True,original_full_study_complete=False,stopping_rule_verified=True,worker_stopped_verified=True)
write_json(D/'audit.json',audit)
write_json(D/'completion.json',{'status':summary['status'],'completed_at':datetime.now(timezone.utc).isoformat(),'original_50_round_protocol_completed':False,'active_seed':7,'subagent_calls':len(returned),'completed_rounds':len(complete),'stop_reason':stop['reason']})
reason='相对参考成本差已低于 0.1%，按用户要求提前停止' if stop['reason'].startswith('reference') else '已完成用户修改后的 10 轮上限，按要求停止'
lines=['# Astra 子代理实验停止报告','',f"{reason}。最佳可行成本 **{best['objective']:,.6f}**，参考成本 **{ref:,.6f}**，相对参考差 **{best['objective']/ref-1:.6%}**。",'',
 f"已完成 {len(complete)} 个完整轮次，实际调用 {len(returned)} 个独立 gpt-6-astra / max 子代理。最佳解在第 {best['iteration']} 轮获得。求解进程已核实退出，未启动其他种子。",
 '若在本轮候选验证时触发停止，该轮仅保留已经完成验证的候选；不把剩余候选计为已评价。','',
 '## 逐轮结果','','|轮次|完整轮次|截至该轮最佳成本|相对参考差|原始/接受/已验证可行候选|修复位数|','|---|---|---:|---:|---|---|']
for r in rounds:
 lines.append(f"|{r['iteration']}|{'是' if r['complete'] else '提前停止，部分'}|{r['best_cost']:.6f}|{r['best_cost']/ref-1:.6%}|{r['raw_candidates']}/{r['accepted_candidates']}/{r['evaluated_feasible_llm_candidates']}|{r['repair_bits']}|")
lines+=['','## 输入与审计','',
 '沿用原实验的数据、动态 QUBO、SA 参数、提示词、修复器及三场景验证。种子 7 首轮 system/user 输入与旧 DeepSeek 试验逐字节一致。每轮均为全新子代理，仅接收该轮输入；没有把参考解或停止阈值提供给子代理。',
 '子代理调用未设置输出 token 上限；实际 token 用量未知，不能称为无限推理。该工具不能设置温度。没有外部 LLM HTTP 请求或量子真机调用。',
 f"独立审计共通过 {audit['validated_candidates']} 份可行调度（包含复用 SA 对照），最大物理残差 {audit['maximum_physical_residual_mw']:.3g} MW，最大成本残差 {audit['maximum_cost_residual']:.3g}。源码快照一致、旧轨迹未变、密钥排除检查通过。",
 '', '## 解释边界','',
 '原计划为 5 个种子各 50 轮。用户在看到中途结果后修改为当前种子最多 10 轮、差距低于 0.1% 提前停。本报告保留这项事后停止规则，因此不是完整的原定对照实验，不能据此估计跨种子平均性能。',
 '相对参考成本差是与一份独立可行参考解的成本比较，不是认证最优性 gap。复用的纯 SA 对照共有 50 轮，不能将它与本次提前停止终点称为同轮数比较。',
 '记录的请求耗时包含主聊天调度、文件读写及等待；第 6 轮还包含用户修改计划期间的等待，不应用于模型纯推理速度排名。',
 '', '证据：[汇总](final-summary.json)、[最佳调度](best-schedule.json)、[审计](audit.json)、[停止触发记录](stop-trigger.json)、[协议修改](protocol-amendment.json)、[逐轮原始输入和输出](runs/sa_llm__s7/calls/)。']
(D/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(D/'live-status.md').write_text('\n'.join(lines[:5])+'\n\n实验已停止。详细结果见 report.md。\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('rounds','reused_baseline')}))
