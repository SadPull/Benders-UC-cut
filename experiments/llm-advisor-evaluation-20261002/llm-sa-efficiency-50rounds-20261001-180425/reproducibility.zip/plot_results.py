"""Descriptive plots of complete paired runs only; no additional optimization."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from suc_benders.efficiency_experiment import read_events

directory=Path(__file__).resolve().parent
summary=json.loads((directory/'summary.json').read_text(encoding='utf-8'))
seeds=[p['seed'] for p in summary['pairs']]
reference=summary['reference']
grid=np.arange(10,601,5)
fig,axes=plt.subplots(1,2,figsize=(12,4.5))
for strategy,color,label in [('sa','#1769aa','SA'),('sa_llm','#d97706','SA + LLM')]:
    curves=[]
    for seed in seeds:
        events=read_events(directory/'runs'/f'{strategy}__s{seed}'/'events.jsonl')
        values=[e for e in events if e['kind']=='evaluation' and e['feasible'] and e['elapsed_seconds']<=600]
        curves.append([min((e['objective'] for e in values if e['elapsed_seconds']<=t),default=np.nan) for t in grid])
    mean=(np.mean(curves,axis=0)/reference-1)*100
    axes[0].step(grid,mean,where='post',label=label,color=color,linewidth=2)
axes[0].set(xlabel='Elapsed time (s)',ylabel='Mean feasible-cost difference from reference (%)',ylim=(0,None))
axes[0].legend()
axes[0].grid(alpha=.2)
deltas=[p['cost_delta_llm_minus_sa'] for p in summary['pairs']]
axes[1].bar([str(s) for s in seeds],deltas,color='#d97706')
axes[1].axhline(0,color='black',linewidth=.8)
axes[1].set(xlabel='Seed',ylabel='50-round final cost: SA + LLM minus SA',title='Positive values favor SA')
axes[1].grid(axis='y',alpha=.2)
fig.suptitle(f'{len(seeds)} complete seed pairs, 50 rounds per run; left: first 600 seconds; right: final cost')
fig.tight_layout()
fig.savefig(directory/'comparison.png',dpi=170)
plt.close(fig)
