$ErrorActionPreference = 'Stop'
Set-Location 'C:/Users/12433/Desktop/LLM-benders-SUC'
$studyRoot = 'results/llm-sa-efficiency-50rounds-20261001-180425'
$existing = Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -match 'suc_benders\.efficiency_experiment' }
if ($existing) { throw 'An experiment supervisor already exists; refusing duplicate launch.' }
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:PYTHONIOENCODING = 'utf-8'
$studyStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$studyOut = "$studyRoot/resume-$studyStamp.out.log"
$studyErr = "$studyRoot/resume-$studyStamp.err.log"
$studyPython = (Get-Command python).Source
$studyArgs = @('-u', '-m', 'suc_benders.efficiency_experiment', '--output-dir', $studyRoot, '--rounds', '50', '--resume')
$studyChild = Start-Process -FilePath $studyPython -ArgumentList $studyArgs -WorkingDirectory (Get-Location).Path -WindowStyle Hidden -RedirectStandardOutput $studyOut -RedirectStandardError $studyErr -PassThru
$studyMeta = [ordered]@{
    command = "python $($studyArgs -join ' ')"
    started_at = (Get-Date).ToString('o')
    pid = $studyChild.Id
    process_started_at = $studyChild.StartTime.ToString('o')
    wrapper_pid = $PID
    stderr = $studyErr
    stdout = $studyOut
    rounds = 50
    output_dir = $studyRoot
    recovery_ledger = "$studyRoot/recovery-20261001.json"
}
$studyMeta | ConvertTo-Json | Set-Content 'results/farluna-50rounds-process.json' -Encoding utf8
$studyChild.WaitForExit()
$studyMeta['exitcode'] = $studyChild.ExitCode
$studyMeta['exited_at'] = (Get-Date).ToString('o')
$studyMeta | ConvertTo-Json | Set-Content 'results/farluna-50rounds-process.json' -Encoding utf8
& $studyPython -c "import runpy; runpy.run_path('$studyRoot/finish_study.py', run_name='__main__')" *> "$studyRoot/postprocess-resumed.log"
if ($LASTEXITCODE -ne 0) { throw 'Offline postprocessing failed; see postprocess-resumed.log.' }
