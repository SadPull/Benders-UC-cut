Wait-Process -Id 11596 -ErrorAction SilentlyContinue
python -c "import runpy; runpy.run_path('results/llm-sa-efficiency-50rounds-20261001-180425/finish_study.py', run_name='__main__')"

