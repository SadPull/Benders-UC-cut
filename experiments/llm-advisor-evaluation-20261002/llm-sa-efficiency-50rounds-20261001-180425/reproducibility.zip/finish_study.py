"""Postprocess once the experiment supervisor has exited; never rerun optimization."""
import json
import runpy
from pathlib import Path
root=Path(__file__).resolve().parent
try:
    from suc_benders.efficiency_experiment import report
    report(root)
    states=[json.loads(p.read_text()) for p in (root/'runs').glob('*/state.json')]
    for name in ['audit_experiment.py','analyze_llm.py']:
        runpy.run_path(str(root/name),run_name='__main__')
    summary=json.loads((root/'summary.json').read_text())
    if summary['pairs']:
        runpy.run_path(str(root/'plot_results.py'),run_name='__main__')
    complete=len(states)==10 and all(s['status']=='completed' for s in states)
    result={'status':'completed' if complete else 'incomplete','runs':len(states),'pairs':len(summary['pairs']),
            'statistics':summary['statistics'],'audit_passed':True}
except Exception as exc:
    result={'status':'postprocess_failed','error_type':type(exc).__name__}
(root/'completion.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
