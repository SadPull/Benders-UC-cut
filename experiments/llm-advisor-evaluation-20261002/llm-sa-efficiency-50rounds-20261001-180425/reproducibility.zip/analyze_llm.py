"""Post-run attribution from recorded events only; no optimization or API calls."""
import json
from collections import Counter
from pathlib import Path
from suc_benders.efficiency_experiment import read_events

root = Path(__file__).resolve().parent
rows = []
for path in sorted((root / "runs").glob("sa_llm__*")):
    state = json.loads((path / "state.json").read_text(encoding="utf-8"))
    if state["status"] == "running":
        raise RuntimeError("Wait for all timed experiments to finish")
    events = read_events(path / "events.jsonl")
    calls = [e["diagnostics"] for e in events if e["kind"] == "llm_end"]
    proposals = [p for d in calls for p in d.get("proposals", [])]
    best = float("inf")
    improvements = []
    full_llm = []
    for e in events:
        if e["kind"] != "evaluation" or not e["feasible"] or e["elapsed_seconds"] > (state["budget"] if state["budget"] is not None else float("inf")):
            continue
        if e["source"] == "llm":
            full_llm.append(e["objective"])
            if e["objective"] < best - 1e-4:
                improvements.append({"seconds": e["elapsed_seconds"], "sa_calls": e["sa_calls"],
                    "previous": best, "objective": e["objective"], "reduction": best-e["objective"]})
        best = min(best, e["objective"])
    rows.append({"run": path.name, "state": state["status"],
        "requests": sum(e["kind"] == "llm_start" for e in events),
        "completed_diagnostics": len(calls),
        "messages": dict(Counter(d.get("message") for d in calls)),
        "stop_reasons": dict(Counter(str(d.get("stop_reason")) for d in calls)),
        "returned_models": sorted(set(d["returned_model"] for d in calls if d.get("returned_model"))),
        "completed_seconds": [d.get("elapsed_seconds") for d in calls],
        "usage": [d.get("usage") for d in calls],
        "proposals": len(proposals),
        "raw_discrete_feasible": sum(bool(p.get("raw_discrete_feasible")) for p in proposals),
        "repair_changed": sum(bool(p.get("repair_changed")) for p in proposals),
        "outcomes": dict(Counter(p.get("outcome") for p in proposals)),
        "direct_llm_feasible_evaluations": len(full_llm),
        "direct_llm_best": min(full_llm, default=None),
        "direct_llm_incumbent_improvements": improvements})
(root / "llm-attribution.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False, indent=2))
