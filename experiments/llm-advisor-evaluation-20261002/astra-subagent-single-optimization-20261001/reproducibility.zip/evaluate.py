"""Offline evaluation of one frozen subagent answer; no model or HTTP calls."""
import os
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
import numpy as np
from suc_benders.attribution import validate_schedule
from suc_benders.candidates import commitment_hash, make_candidate
from suc_benders.data import load_suc_data
from suc_benders.efficiency_experiment import configuration, read_events
from suc_benders.llm import ask_llm_for_candidates
from suc_benders.solver import _fixed_cost, result_to_dict
from suc_benders.subproblem import solve_scenario

r = Path(__file__).resolve().parent


def save(name, value):
    (r / name).write_text(json.dumps(result_to_dict(value), ensure_ascii=False,
                                   indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    started = time.perf_counter()
    candidate_text = (r / "candidates.json").read_text(encoding="utf-8")
    parsed = json.loads(candidate_text)
    assert isinstance(parsed, dict) and isinstance(parsed.get("candidates"), list)
    assert len(parsed["candidates"]) <= 4
    provenance = json.loads((r / "provenance.json").read_text(encoding="utf-8"))
    for name, expected in provenance["business_input_sha256"].items():
        assert hashlib.sha256((r / name).read_bytes()).hexdigest() == expected
    system = (r / "system.txt").read_text(encoding="utf-8")
    user = (r / "user.txt").read_text(encoding="utf-8")
    body = json.loads(user)
    source = ROOT / "results/llm-sa-efficiency-50rounds-20261001-180425/runs/sa_llm__s17/events.jsonl"
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    events = read_events(source)
    start_index = next(i for i, e in enumerate(events)
                       if e["kind"] == "llm_start" and e["iteration"] == 15)
    prior = events[:start_index]
    baseline = min((e for e in prior if e["kind"] == "evaluation" and e["feasible"]),
                   key=lambda e: e["objective"])
    cache = {e["commitment_id"]: e for e in prior if e["kind"] == "evaluation"}
    data, scenarios = load_suc_data(ROOT / "data/suc_10x24.json")
    assert np.array_equal(body["incumbent_u"], baseline["u"])
    incumbent = make_candidate(data, scenarios, np.array(body["incumbent_u"]), source="incumbent")
    config = replace(configuration(17, "sa_llm", rounds=50).llm,
                     api_format="responses", model="gpt-6-astra")
    # Reuse exactly the production candidate parser/repair in a synthetic envelope.
    # The mocked transport cannot contact any endpoint or invoke another model.
    envelope = {"status": "completed", "model": "gpt-6-astra", "output": [
        {"type": "message", "role": "assistant", "content": [
            {"type": "output_text", "text": candidate_text}]}]}
    response = Mock()
    response.status = 200
    response.read.return_value = json.dumps(envelope).encode()
    response.__enter__ = Mock(return_value=response)
    response.__exit__ = Mock(return_value=False)
    opener = Mock()
    opener.open.return_value = response
    with patch.dict(os.environ, {"LLM_API_KEY": "offline-validation"}), \
         patch("suc_benders.llm.build_opener", return_value=opener), \
         patch("suc_benders.llm._prompt", return_value=(system, user)):
        advice = ask_llm_for_candidates(data, scenarios, 15, [], incumbent, config,
                                        context=body["context"])
    assert opener.open.call_count == 1 and not advice.failed
    save("local-validation-diagnostics.json", {
        "synthetic_envelope": True, "http_requests": 0, "diagnostics": advice.diagnostics})
    best = baseline["objective"]
    evaluations = []
    dispatch_calls = 0
    for candidate in advice.candidates:
        key = commitment_hash(candidate)
        if key in cache:
            old = cache[key]
            evaluations.append({"commitment_id": key, "cached": True,
                                "feasible": old["feasible"], "objective": old["objective"]})
            continue
        results = []
        for scenario in scenarios:
            results.append(solve_scenario(data, scenario, candidate.u, candidate.v,
                                          candidate.w, output_flag=0, threads=1))
            dispatch_calls += 1
        feasible = all(x.feasible for x in results)
        row = {"commitment_id": key, "cached": False, "feasible": feasible,
               "objective": None, "u": candidate.u, "v": candidate.v, "w": candidate.w,
               "scenario_statuses": [x.status for x in results]}
        if feasible:
            cost = _fixed_cost(data, candidate.u, candidate.v, candidate.w) + sum(
                s.probability * x.objective for s, x in zip(scenarios, results))
            result = SimpleNamespace(objective=cost, u=candidate.u, v=candidate.v,
                                     w=candidate.w, scenarios=[
                                         SimpleNamespace(name=s.name, objective=x.objective, p=x.p, r=x.r)
                                         for s, x in zip(scenarios, results)])
            row.update(objective=cost, validation=validate_schedule(data, scenarios, result),
                       scenarios=[{"name": s.name, "objective": x.objective, "p": x.p, "r": x.r}
                                  for s, x in zip(scenarios, results)])
            best = min(best, cost)
        evaluations.append(row)
        print(json.dumps({"candidate": len(evaluations), "feasible": feasible,
                          "objective": row["objective"]}), flush=True)
    save("evaluations.json", evaluations)
    reference = json.loads((ROOT / "results/llm-sa-efficiency-50rounds-20261001-180425/reference.json").read_text(encoding="utf-8"))["objective"]
    summary = {
        "status": "completed", "model": "gpt-6-astra", "subagent_calls": 1,
        "http_requests": 0, "sa_calls": 0, "dispatch_calls": dispatch_calls,
        "raw_candidates": advice.raw_count, "accepted_candidates": advice.valid_count,
        "new_feasible_candidates": sum(x["feasible"] and not x["cached"] for x in evaluations),
        "cached_candidates": sum(x["cached"] for x in evaluations),
        "baseline_objective": baseline["objective"], "best_objective": best,
        "improvement": baseline["objective"] - best,
        "improvement_percent": 100 * (baseline["objective"] - best) / baseline["objective"],
        "reference_objective": reference, "reference_difference_percent": 100 * (best / reference - 1),
        "local_validation_seconds": time.perf_counter() - started,
        "candidate_file_sha256": hashlib.sha256((r / "candidates.json").read_bytes()).hexdigest(),
        "observed_agent_seconds": (r / "candidates.json").stat().st_mtime
            - datetime.fromisoformat(provenance["dispatch_confirmed_at"]).timestamp(),
        "observed_agent_seconds_note": "From confirmation of dispatch to file write; excludes earlier dispatch overhead, includes input-read/output-write tools. Not API latency.",
        "model_token_usage": None, "source_events_unchanged": hashlib.sha256(source.read_bytes()).hexdigest() == source_hash,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    save("summary.json", summary)
    save("status.json", {"status": "completed", "subagent_calls": 1})
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
