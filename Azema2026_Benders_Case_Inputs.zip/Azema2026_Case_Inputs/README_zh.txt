Azéma 2026：Benders 未达标算例的公开输入资料
整理日期：2026-10-10

一、资料性质
本包收录作者公开仓库中与所筛选失败组对应的原始数值数据，以及按作者代码核对的24组输入配置。
未运行优化求解器；没有独立复现论文的未收敛结果或最终gap。实例名称只是本次整理的索引名称。
原始数据按字节保留；全部13个文件的来源和SHA256见provenance.json。

论文：Mathis Azéma, Vincent Leclère, Wim van Ackooij.
Stronger cuts for Benders’ decomposition for stochastic Unit Commitment Problems based on interval variables.
DOI：https://doi.org/10.1007/s12532-026-00334-1
作者稿：https://optimization-online.org/wp-content/uploads/2025/11/nonmarked.pdf
代码：https://github.com/MathisAzema/BDSUC
固定提交：5b9cf5ec2795b481f4d65c364be37eacfd0b585b

二、对应哪些失败配置
A. Table 1，第23页：SMS++，100台机组、24小时、100场景，传统3-bin BD。
Data/T-Ramp/100_0_1_w.nc4 至 100_0_5_w.nc4 共5个基础文件，各配3个场景批次，得到15组配置。
batch=1：第1—100个日场景；batch=2：第101—200个；batch=3：第201—300个。
force=1.0，S=100，gap=0.1（此接口单位为百分数），timelimit=3600秒。
论文组结果：0/15达标，平均最终gap为7.47%。这个平均值不代表每一例各自的gap。
training_set.csv提供固定误差序列，无需重新抽取随机数；test_set.csv虽不用于这组训练内求解，但原解析器会读取它，所以一起保留。

B. Table 1：IEEE118，54台机组、24小时、100场景，传统3-bin BD。
使用Data/IEEE/118_syst内6个CSV；batch=1,2,3，S=100，force=1.0。
场景范围同A。论文组结果：0/3达标，平均最终gap为1.92%。

C. Table 3，第26页：IEEE118，54台机组、24小时、50场景，Extended BD-H。
使用同一IEEE目录；S=50，force=2.0或3.0，对应论文sigma=2或3；每种force取batch=1,2,3。
三批分别取第1—50、101—150、201—250个日场景，不能误取为连续150天再分组。
论文组结果：sigma=2时0/3达标、平均gap4.44%；sigma=3时0/3达标、平均gap1.56%。
实验设置统一目标gap为0.1%，统一预算3600秒；Table3表头不再次重复时限。

三、如何交给作者代码读取
本包只含数值数据和说明，作者求解代码及Julia项目文件从上面的固定仓库提交取得。
在作者仓库根目录使用其Project.toml/Manifest.toml，准备可工作的Julia/JuMP/Gurobi环境。
已核对的解析和求解入口如下；以下是配置说明，未执行过求解。

准备优化器：
using BDSUC, JuMP, Gurobi
const GRB_ENV = Gurobi.Env()
optimizer = () -> Gurobi.Optimizer(GRB_ENV)

A的第一个实例：
instance = BDSUC.parse_nc4("Data/T-Ramp/100_0_1_w.nc4", optimizer, 24)
res = BDSUC.benders3bin_callback(instance, BDSUC.binBD; silent=false, force=1.0, S=100, batch=1, gap=0.1, timelimit=3600)

B的第一个实例：
instance = BDSUC.parse_IEEE("118_syst", optimizer)
res = BDSUC.benders3bin_callback(instance, BDSUC.binBD; silent=false, force=1.0, S=100, batch=1, gap=0.1, timelimit=3600)

C中sigma=2的第一个实例：
instance = BDSUC.parse_IEEE("118_syst", optimizer)
res = BDSUC.benders_callback(instance, BDSUC.extended_BD_FH_OH; silent=false, force=2.0, S=50, batch=1, gap=0.1, timelimit=3600)

完整24项参数见case_index.json。函数中的gap=0.1会再除以100后传入Gurobi，对应0.1%。

四、复现前需要注意的已核实差异
1. 作者公开IEEE的lines.csv有179条线路记录，论文描述186条。与标准MATPOWER case118比较，179对应唯一无向端点对；7组并联线路没有使用并联等值电抗。因此不能把这一差异当作已证明无影响，也不要自行换入标准case118后仍称原实例。
2. test.jl默认注释传统3-bin BD。注释段中统计数组使用[batch]，循环下一个基础文件时可能覆盖上一个文件的统计。建议逐个配置调用并独立保存日志，不应只取消注释就依赖其最后聚合数。
3. 公开仓库未找到逐实例结果日志；已取得公开数据及相应配置，不等于确认其与论文运行版本完全一致。
4. 更换求解器、版本、硬件、割策略后是否在一小时内未收敛，需要重新实测。

五、包内数据结构
Data/T-Ramp/：5个100机组NC4基础数据。
Data/Uncertainty/：training_set.csv及test_set.csv。
Data/IEEE/118_syst/：generators.csv、lines.csv、maximum_load.csv、load_distribution_profile.csv、maximum_renewable_generation.csv、renewable_generation_profile.csv。
case_index.json：24组配置，场景范围均为从1开始的闭区间。
provenance.json：来源链接、固定提交、原文件大小和SHA256。
OTHER_TWO_PAPERS.txt：另外两篇论文的具体配置、公开基础数据入口和复现缺口。
